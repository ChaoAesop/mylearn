package pagemodel;

public class MSG {
	String state;
	
	public MSG(String state) {
		this.state = state;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
}
