package service;


public interface LoginService {
	String getpwdbyname(String name);
}
